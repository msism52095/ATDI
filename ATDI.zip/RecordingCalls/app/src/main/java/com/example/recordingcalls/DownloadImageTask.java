package com.example.recordingcalls;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
    @Override
    protected Bitmap doInBackground(String... urls) {
        // Perform the download and processing of the image in the background
        String url = urls[0];
        Bitmap bitmap = null;
        try {
            InputStream in = new java.net.URL(url).openStream();
            bitmap = BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
            e.printStackTrace();
        }

        // First, you need to check if external storage is available and writable
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {


            // Define the directory where the image will be saved
            File directory = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), "MyAppFolder");

            // Create the directory if it doesn't exist
            if (!directory.exists()) {
                directory.mkdirs();
            }

            // Generate a unique filename for the image
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String filename = "IMG_" + timestamp + ".jpg";

            // Create the file object for the image
            File file = new File(directory, filename);

            // Save the bitmap to the file
            FileOutputStream outputStream;
            try {
                outputStream = new FileOutputStream(file);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                outputStream.flush();
                outputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Notify the MediaScanner to scan the new image file and make it available in the Gallery
            MediaScannerConnection.scanFile(MainActivity.mainBinding.getRoot().getContext(), new String[]{file.getPath()}, null, null);
            }
        return bitmap;
    }

    @Override
    protected void onPostExecute(Bitmap result) {
        // Update the UI with the downloaded image
        MainActivity.mainBinding.progressBar.setVisibility(View.INVISIBLE);
        MainActivity.mainBinding.imageView.setImageBitmap(result);
    }

    @Override
    protected void onPreExecute() {
        // Show a progress bar or other UI element indicating that the image is being downloaded
        MainActivity.mainBinding.progressBar.setVisibility(View.VISIBLE);

    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);

    }
}
