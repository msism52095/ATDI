package com.example.recordingcalls;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.Toast;

import com.example.recordingcalls.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    protected BroadcastReceiver incomingCallReceiver;

    public static ActivityMainBinding mainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());



        DownloadImageTask downloadTask = new DownloadImageTask();
        downloadTask.execute("https://www.w3schools.com/w3images/fjords.jpg");

//        incomingCallReceiver = new IncomingCallReceiver();
//
//        IntentFilter filter = new IntentFilter(TelephonyManager.EXTRA_STATE);
//        registerReceiver(incomingCallReceiver, filter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

//        unregisterReceiver(incomingCallReceiver);
    }
}